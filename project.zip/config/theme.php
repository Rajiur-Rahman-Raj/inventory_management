<?php
return [
    'original' => [
        'title' => 'Original Theme',
        'path' => 'assets/uploads/theme/original_theme.png',
    ]
];
