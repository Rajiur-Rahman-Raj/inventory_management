<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'Real state investment,  Chaincity, Chaincity investment, Chaincity website, invest, investment, Investment Management system, investment script, Bug Finder, bug-finder, bugfinder.net, bugfinder',
  'meta_description' => 'Chaincity,  A Modern Chaincity Real State Investmet Platform',
  'social_title' => 'Chaincity,  A Chaincity Real State Investmet Platform',
  'social_description' => 'Chaincity,  A Chaincity Real State Investmet Platform',
);