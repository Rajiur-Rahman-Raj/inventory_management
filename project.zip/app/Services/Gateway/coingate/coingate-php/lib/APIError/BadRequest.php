<?php

namespace CoinGate\APIError;

# HTTP Status 400
class BadRequest extends APIError
{
}
