@extends($theme.'layouts.user')
@section('title', trans('Customer List'))
@section('content')
    @push('style')
        <link rel="stylesheet" href="{{ asset('assets/global/css/bootstrap-datepicker.css') }}"/>
    @endpush
    <!-- Invest history -->
    <section class="transaction-history">
        <div class="container-fluid">
            <div class="row mt-4 mb-2">
                <div class="col ms-2">
                    <div class="header-text-full">
                        <h3 class="dashboard_breadcurmb_heading mb-1">@lang('Customer List')</h3>
                        <nav aria-label="breadcrumb" class="ms-2">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ route('user.home') }}">@lang('Dashboard')</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">@lang('Customer List')</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- search area -->
            <div class="search-bar mt-3 me-2 ms-2 p-0">
                <form action="" method="get" enctype="multipart/form-data">
                    <div class="row g-3 align-items-end">
                        <div class="input-box col-lg-2">
                            <label for="">@lang('Name')</label>
                            <input
                                type="text"
                                name="name"
                                value="{{ old('name', @request()->name) }}"
                                class="form-control"
                                placeholder="@lang('Customer Name')"
                            />
                        </div>

                        <div class="input-box col-lg-2">
                            <label for="">@lang('Email')</label>
                            <input
                                type="text"
                                name="email"
                                value="{{ old('email', @request()->email) }}"
                                class="form-control"
                                placeholder="@lang('Customer Email')"
                            />
                        </div>

                        <div class="input-box col-lg-2">
                            <label for="">@lang('Phone')</label>
                            <input
                                type="text"
                                name="phone"
                                value="{{ old('phone', @request()->phone) }}"
                                class="form-control"
                                placeholder="@lang('Customer Phone')"/>
                        </div>

                        <div class="input-box col-lg-2">
                            <label for="from_date">@lang('From Date')</label>
                            <input
                                type="text" class="form-control datepicker from_date" name="from_date"
                                value="{{ old('from_date',request()->from_date) }}" placeholder="@lang('From date')"
                                autocomplete="off" readonly/>
                        </div>
                        <div class="input-box col-lg-2">
                            <label for="to_date">@lang('To Date')</label>
                            <input
                                type="text" class="form-control datepicker to_date" name="to_date"
                                value="{{ old('to_date',request()->to_date) }}" placeholder="@lang('To date')"
                                autocomplete="off" readonly disabled="true"/>
                        </div>

                        <div class="input-box col-lg-2">
                            <button class="btn-custom w-100" type="submit"><i class="fal fa-search"></i>@lang('Search')
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="d-flex justify-content-end mb-4">
                <a href="{{route('user.createCustomer')}}" class="btn btn-custom text-white "> <i
                        class="fa fa-plus-circle"></i> @lang('Add Customer')</a>
            </div>

            <div class="table-parent table-responsive me-2 ms-2 mt-4">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">@lang('SL')</th>
                        <th scope="col">@lang('Name')</th>
                        <th scope="col">@lang('Phone')</th>
                        <th scope="col">@lang('Division')</th>
                        <th scope="col">@lang('District')</th>
                        <th scope="col">@lang('Join Date')</th>
                        <th scope="col">@lang('Action')</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($customers as $key => $customer)
                        <tr>
                            <td data-label="@lang('SL')">{{loopIndex($customers) + $key}}</td>

                            <td class="company-logo" data-label="@lang('Name')">
                                <div>
                                    <a href=""
                                       target="_blank">{{ $customer->name }}</a>
                                    <br>
                                    @if($customer->email)
                                        <span class="text-muted font-14">
                                        <span>{{ $customer->email }}</span>
                                    </span>
                                    @endif
                                </div>
                            </td>

                            <td data-label="@lang('Phone')">{{ $customer->phone }}</td>
                            <td data-label="@lang('Division')">{{ optional($customer->division)->name }}</td>
                            <td data-label="@lang('District')">{{ optional($customer->district)->name }}</td>
                            <td data-label="@lang('Join Date')">{{ dateTime($customer->created_at) }}</td>

                            <td data-label="Action">
                                <div class="sidebar-dropdown-items">
                                    <button
                                        type="button"
                                        class="dropdown-toggle"
                                        data-bs-toggle="dropdown"
                                        aria-expanded="false"
                                    >
                                        <i class="fal fa-cog"></i>
                                    </button>

                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a href="{{ route('user.customerDetails', $customer->id) }}"
                                               class="dropdown-item"> <i class="fal fa-eye"></i> @lang('Details') </a>
                                        </li>

                                        <li>
                                            <a class="dropdown-item btn" href="{{ route('user.customerEdit', $customer->id) }}">
                                                <i class="fas fa-edit"></i> @lang('Edit')
                                            </a>
                                        </li>

                                        <li>
                                            <a class="dropdown-item btn deleteCustomer"
                                               data-route="{{route('user.deleteCustomer', $customer->id)}}"
                                               data-property="{{ $customer }}">
                                                <i class="fas fa-trash-alt"></i> @lang('Delete')
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr class="text-center">
                            <td colspan="100%" class="text-danger text-center">{{trans('No Data Found!')}}</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    @push('loadModal')
        <!-- Modal -->
        <div class="modal fade" id="deleteCustomerModal" tabindex="-1" aria-labelledby="editModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-top modal-md">
                <div class="modal-content">
                    <div class="modal-header modal-primary modal-header-custom">
                        <h4 class="modal-title">@lang('Delete Confirmation')</h4>
                        <button type="button" class="close-btn" data-bs-dismiss="modal" aria-label="Close">
                            <i class="fal fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <span class="delete-customer-name"></span>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-custom btn2 btn-secondary close_invest_modal close__btn"
                                data-bs-dismiss="modal">@lang('No')</button>
                        <form action="" method="post" class="deleteCustomerRoute">
                            @csrf
                            @method('delete')
                            <button type="submit"
                                    class="btn btn-sm btn-custom text-white">@lang('Yes')</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endpush
@endsection

@push('script')
    <script src="{{ asset('assets/global/js/bootstrap-datepicker.js') }}"></script>
    <script>
        'use strict'
        $(document).ready(function () {
            $(".datepicker").datepicker({
                autoclose: true,
                clearBtn: true
            });

            $('.from_date').on('change', function () {
                $('.to_date').removeAttr('disabled');
            });

            $(document).on('click', '.deleteCustomer', function () {
                var deleteCustomerModal = new bootstrap.Modal(document.getElementById('deleteCustomerModal'))
                deleteCustomerModal.show();

                let dataRoute = $(this).data('route');
                let dataProperty = $(this).data('property');

                $('.deleteCustomerRoute').attr('action', dataRoute)

                $('.delete-customer-name').text(`Are you sure to delete ${dataProperty.name}?`)

            });
        });
    </script>
@endpush
