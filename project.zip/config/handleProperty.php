<?php

return [
  'all' => [
      'title' => 'All Properties',
      'property_view' => 'admin.property.list',
  ],
    'upcoming' => [
        'title' => 'Upcoming Properties',
        'property_view' => 'admin.property.list',
    ],
    'running' => [
        'title' => 'Running Properties',
        'property_view' => 'admin.property.list',
    ],
    'expired' => [
        'title' => 'Expired Properties',
        'property_view' => 'admin.property.list',
    ],
];
