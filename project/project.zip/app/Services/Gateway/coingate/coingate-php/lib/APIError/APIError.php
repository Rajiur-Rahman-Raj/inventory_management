<?php

namespace CoinGate\APIError;

class APIError extends \Exception
{
}
